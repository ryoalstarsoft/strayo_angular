// tslint:disable-next-line:class-name
export interface Mtljs {
    [s: string]: {
        map_Kd: string;
    };
}
