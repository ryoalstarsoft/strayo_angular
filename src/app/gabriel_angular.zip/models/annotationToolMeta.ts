import { AnnotationToolType } from './annotationToolType';

export interface IAnnotationToolMeta {
    name: string;
    tool: AnnotationToolType;
}