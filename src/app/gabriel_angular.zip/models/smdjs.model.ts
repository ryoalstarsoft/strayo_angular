// tslint:disable-next-line:class-name
export interface Smdjs {
    Material: string;
    Meshes: string[];
}
