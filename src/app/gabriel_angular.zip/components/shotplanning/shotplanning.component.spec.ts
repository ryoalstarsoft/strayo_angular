import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shotplanning',
  templateUrl: './shotplanning.component.html',
  styleUrls: ['./shotplanning.component.css']
})
export class ShotplanningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}