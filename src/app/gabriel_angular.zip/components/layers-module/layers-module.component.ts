import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layers-module',
  templateUrl: './layers-module.component.html',
  styleUrls: ['./layers-module.component.css']
})
export class LayersModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}